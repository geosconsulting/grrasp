<!-- <?php include_once 'php/geoproxy.php'; ?> -->
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<!--CUSTOM SECTION BEGIN-->
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="css/toolbar.css" type="text/css">
<link rel="stylesheet" href="css/fileUploaderEast.css" type="text/css">
<link rel="stylesheet" href="css/loader.css" type="text/css">
<link rel="stylesheet" href="js/FileBrowser/css/FileBrowserPanel.css" type="text/css">
<link rel="stylesheet" href="css/finestraEdit.css" type="text/css">

<noscript>We are sorry, GRRASP Platform was unable to load. In order to run the platform you must have 
    Javascript enabled. If your web browser doesn't support Javascript you will need to install one that does. 
	Choices Firefox 2+, Safari 2+.</noscript>
<div id="loading">
	<div class="loading-mask"></div>
	<div class="loading-container">
		<div class="loading-indicator">
			<img src="img/loading/large-loading.gif"
			width="48" height="32" style="margin-right:8px;float:left;vertical-align:top;">GR<sup>2</sup>ASP<br/>
			<span id="loading-msg">Loading...</span>
		</div>
	</div>
</div>

<!-- BigG layers -->
<script src="http://maps.google.com/maps/api/js?v=3&amp;sensor=false"></script> 

<!--LIBRERIE UTILITA' VARIE -->
<script src="js/underscore/underscore-min.js" type="text/javascript"></script>	
<!--LIBRERIE UTILITA' VARIE -->

<!--EXT SECTION BEGIN-->
<link rel="stylesheet" type="text/css" href="js/ext-3.3.1/resources/css/ext-all.css">
<link rel="stylesheet" type="text/css" href="js/ext-3.3.1/resources/css/xtheme-gray.css">
<script type="text/javascript" src="js/ext-3.3.1/adapter/ext/ext-base.js" ></script>  
<script type="text/javascript" src="js/ext-3.3.1/ext-all.js" ></script>  
<!--EXT SECTION END-->

<!--EXT UX SECTION BEGIN-->
<link rel="stylesheet" type="text/css" href="js/ext-3.3.1/examples/ux/css/Spinner.css">
<link rel="stylesheet" type="text/css" href="css/fileuploadfield.css">
<script type="text/javascript" src="js/ext-3.3.1/examples/ux/Spinner.js"></script>
<script type="text/javascript" src="js/ext-3.3.1/examples/ux/SpinnerField.js"></script>
<script type="text/javascript" src="js/ext-community-extensions/FileUploadField.js"></script>
<script type="text/javascript" src="js/FileBrowser/Ext.ux.FileBrowserPanel.js"></script>    
<!-- <script type="text/javascript" src="js/ext-3.3.1/examples/ux/CheckColumn.js"></script> -->
<!--EXT UX SECTION END-->

<!--OPENLAYERS SECTION BEGIN-->
<link rel="stylesheet" type="text/css" href="js/ol/theme/default/style.css" >
<script type="text/javascript" src="js/ol/OpenLayers.js"></script>
<script type="text/javascript" src="js/ol/LoadingPanel.js"></script>
<!--OPENLAYERS SECTION END-->

<!--GEOEXT SECTION BEGIN-->
<link rel="stylesheet" type="text/css" href="js/geoext/resources/css/geoext-all-debug.css">
<link rel="stylesheet" type="text/css" href="js/geoext/resources/css/gxtheme-gray.css"> 
<script type="text/javascript" src="js/GeoExt-1.1/lib/GeoExt.js"></script>
<!--GEOEXT SECTION END-->

<!--CALCOLI GIS SECTION BEGIN-->
<script type="text/javascript" src="js/custom/calcoliGeospatial/calcVincenty.js"></script>
<!--CALCOLI GIS SECTION END-->

<!--LOGIN/LOGOUT BEGIN-->
<script type="text/javascript" src="js/custom/logging/login.js"></script>
<script type="text/javascript" src="js/custom/logging/logout.js"></script>
<!--LOGIN/LOGOUT END-->

<!--STAMPA BEGIN -->
<script type="text/javascript" src="js/custom/stampa/parametriPrint.js"></script>
<script type="text/javascript" src="js/custom/stampa/printwindow.js"></script> 
<script type="text/javascript" src="http://localhost:8080/geoserver/pdf/info.json?var=printCapabilities"></script>
<!--STAMPA END-->

<!--LAYERS SECTION BEGIN-->
<script type="text/javascript" src="js/custom/layersGeoserver/baseLayers.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSItalianLayers.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSLayersBaseline.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSLayersGas.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSLayersGeoMagnetic.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSLayersElec.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSPolitecnico.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSTransportation.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WFSRegioniEuropee.js"></script> 
<script type="text/javascript" src="js/custom/layersGeoserver/WFSItalianGrid.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WFSRemoteLayers.js"></script>
<script type="text/javascript" src="js/custom/layersGeoserver/WMSLayersLombardy.js"></script>
<!--LAYERS SECTION END-->

<!--SUBSELECTION SECTION BEGIN-->
<script type="text/javascript" src="js/custom/selezioneSottoreti/WFSLocationLayer.js"></script>
<script type="text/javascript" src="js/custom/selezioneSottoreti/selezionaInterfaccia.js"></script>
<script type="text/javascript" src="js/custom/selezioneSottoreti/selezionaGriglia.js"></script>
<script type="text/javascript" src="js/custom/selezioneSottoreti/selezionamappingFields.js"></script>
<script type="text/javascript" src="js/custom/selezioneSottoreti/selezionaAzioni.js"></script>
<script type="text/javascript" src="js/custom/selezioneSottoreti/selezionaSelezioni.js"></script>
<!--SUBSELECTION SECTION END-->

<!--VPORTS MAIN WINDOW SECTION BEGIN-->
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/pannelloRSS.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/componentiVPortsNorthWestSouth.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/populateGrid.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/toolbar.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/pannelloMatlab.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/struttura.js"></script>
<!-- <script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/struttura_print.js"></script> -->
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/layerWindow.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/dataGridSouth.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/helpWin.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/leggiGeoserver.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/layerCancella.js"></script>
<script type="text/javascript" src="js/custom/interfacciaPrincipaleExt/attivaDisattivaToolbar.js"></script>
<script type="text/javascript" src="js/custom/location/eventoGeolocate.js"></script>
<script type="text/javascript" src="js/custom/location/geolocate.js"></script>
<!--VPORTS MAIN WINDOW SECTION END-->

<!--VESTIZIONI DATI WFS SECTION BEGIN-->
<script type="text/javascript" src="js/custom/filteringLegendVectors/nodesLegendRules.js"></script>
<script type="text/javascript" src="js/custom/filteringLegendVectors/nodesLegendFilter.js"></script>
<script type="text/javascript" src="js/custom/filteringLegendVectors/nodesLegendSingle.js"></script>
<!--VESTIZIONI DATI WFS SECTION END-->

<!--WFS TRANSACTIONING SECTION BEGIN-->
<script type="text/javascript" src="js/custom/wfst/WFS-T_rispostaEventoDelete.js"></script>
<script type="text/javascript" src="js/custom/wfst/WFS-T_initDELETE.js"></script>
<script type="text/javascript" src="js/custom/wfst/WFS-T_flashFeatures.js"></script>
<script type="text/javascript" src="js/custom/wfst/WFS-T_snapSplit.js"></script>
<script type="text/javascript" src="js/custom/wfst/WFS-T_stiliVettori.js"></script>
<script type="text/javascript" src="js/custom/wfst/WFS-T_strategie.js"></script>
<!--WFS TRANSACTIONING SECTION END-->

<!--FILTRAGGIO, DATI DB e WFS-T SECTION BEGIN-->
<script type="text/javascript" src="js/custom/editingWindow/interdipendencyModeller.js"></script>
<script type="text/javascript" src="js/custom/editingWindow/nodesEditingWindow.js"></script>
<script type="text/javascript" src="js/custom/editingWindow/linksEditingWindow.js"></script>
<script type="text/javascript" src="js/custom/editingWindow/polyEditingWindow.js"></script>
<script type="text/javascript" src="js/custom/editingWindow/clonaProgetto.js"></script>
<script type="text/javascript" src="js/custom/editingWindow/mergeProgetto.js"></script>
<!--FILTRAGGIO, DATI DB e WFS-T SECTION END-->

<!--SCENARI SECTION BEGIN-->
<script type="text/javascript" src="js/custom/scenariosBuilder/scenarionBuildingWindow.js"></script>
<script type="text/javascript" src="js/custom/scenariosBuilder/riskSimulator.js"></script>
<script type="text/javascript" src="js/custom/scenariosBuilder/geoMagneticSimulator.js"></script>
<!--SCENARI SECTION END-->

<!--CONTROLLI EVENTI SULLA MAPPA CLICK SECTION BEGIN-->
<script type="text/javascript" src="js/custom/mapEventsControls/risposteEventoClickSuNodi.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/rispostaEventoClickEarthquakes.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/handleMeasurements.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/zoomMap.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/getInfoWMS.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/infopopup.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/getInfoInterdependencyWMS.js"></script>
<script type="text/javascript" src="js/custom/mapEventsControls/getInfoNodeInterdependencyWMS.js"></script>
<!--CONTROLLI EVENTI SULLA MAPPA CLICK SECTION END-->

<!--IMPORT/EXPORT/UPLOAD SECTION BEGIN-->
<script type="text/javascript" src="js/custom/importExportUpload/exportWindow.js"></script>
<script type="text/javascript" src="js/custom/importExportUpload/externalServer.js"></script>
<script type="text/javascript" src="js/custom/importExportUpload/uploadWindow.js"></script>
<script type="text/javascript" src="js/custom/importExportUpload/serverWindow.js"></script>
<script type="text/javascript" src="js/custom/importExportUpload/progressWindow.js"></script>
<!--IMPORT/EXPORT/UPLOAD SECTION END-->

<!--AZIONI SECTION END-->
<!--CUSTOM SECTION END -->

<script type="text/javascript">
	var P_4326 		= new OpenLayers.Projection("EPSG:4326");
    var P_900913 	= new OpenLayers.Projection("EPSG:900913");   
    var P_2077 		= new OpenLayers.Projection("EPSG:2077");
    var apiKey 		= "AksO8IfKYy5dmUh5qI5qdgmgd6dINUTwHttW9K-uGTwJORhNbbrmhE5N9RfH5s0v";     

Ext.onReady(function() {		
		
	Ext.QuickTips.init();  
		
	OpenLayers.ProxyHost = "/cgi-bin/proxy.cgi?url=";	
	
	var map = addBaseLayers(P_4326,P_900913,P_2077);
	
	//parametriStampa(map);
	//createPrintForm(map);
				
	addOverlayItalianLayers(map,P_4326,P_900913,P_2077);
	addOverlayTransportationLayers(map,P_4326,P_900913,P_2077);
	addOverlayLayersBaseline(map,P_4326,P_900913,P_2077);
	addOverlayGasLayers(map,P_4326,P_900913,P_2077);
	addOverlayElectricalLayers(map,P_4326,P_900913,P_2077);
	addOverlayGeomagneticLayers(map,P_4326,P_900913,P_2077);
	addOverlayLayersLombardy(map,P_4326,P_900913,P_2077);
	addOverlayPolitecnicoLayers(map,P_4326,P_900913,P_2077);
	stiliVettori();
	strategieDiSalvataggioPerINodiESegmenti();	
	addVectorLayers(map,P_4326,P_900913,P_2077);
	addVectorGridLayers(map,P_4326,P_900913,P_2077);
	addVectorSelectionLayers(map,P_4326,P_900913,P_2077);
	addRemoteVectorLayers(map,P_4326,P_900913);	
	eventoGeoLocation(map);
	preparaGeoLocation(map);		
	infoInterdependencyWMS(map);	    
		
	var toolbar = creaToolbar(map);	
	creaComponentiViewPortNorthWestSouth();
	creaEventoLayerEarthquake(map);
	createScenariosWindow();
	createRiskSimulatorWindow();
	//snapSplit(map); 	
	modelInterdependencies();
	createHelpWindow();		
	
	var mapPanel 		= creaStruttura(map,toolbar);
	var finestraLayer 	= createLayerWindow(mapPanel);  
	var finestraExport 	= createLayerExport(mapPanel);
	var finestraServer 	= createNavigaWindow();	
	
	Ext.Ajax.request({
		method: 'GET',
         waitMsg: 'Please Wait',
         url: 'php/logInOut/readSession.php',
         params: {},
         success:function(utente){
        	 if (utente.responseText=="") {        	 	
        		disattiva(toolbar); 		
 	    	} else {
 	    		attiva(toolbarItems);	    		
 	    	}				
         }
     });
			
	infoNodeInterdependencyWMS(map);	
	writeGridToSouth();
	creaFinestraBufferSize();	
	
	Ext.get('loading').fadeOut({remove: true});
		
});

</script>
<title>GRRASP</title>
</head>
<body>	
	
</body>
</html>